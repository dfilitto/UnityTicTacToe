using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class TicTacToeController : MonoBehaviour
{
    //topo
    private Label labelTurno; //label que indica o turno
    private Label labelPlacarJogador;
    private Label labelPlacarEmpate;
    private Label labelPlacarPC;
    //tabuleiro
    private List<Button> casas = new List<Button>(); //casas
    //rodape
    private Button botaoReiniciar;

    private string[] tabuleiroLogico = new string[9]; //tabuleiro logico
    private bool vezDoJogador = true; //vez do jogador
    private bool jogoAtivo = true; //indica se o jogo est� ativo

    private int vitoriasJogador = 0; //placar jogador
    private int vitoriasPC = 0; //placar pc     
    private int empates = 0; //placar empate

    // Matriz com as 8 combina��es poss�veis de vit�ria
    private readonly int[,] combinacoesVitoria = new int[,]
    {
        {0, 1, 2}, // Linha 0 (Horizontal do topo)
        {3, 4, 5}, // Linha 1 (Horizontal do meio)
        {6, 7, 8}, // Linha 2 (Horizontal de baixo)
        {0, 3, 6}, // Linha 3 (Vertical da esquerda)
        {1, 4, 7}, // Linha 4 (Vertical do centro)
        {2, 5, 8}, // Linha 5 (Vertical da direita)
        {0, 4, 8}, // Linha 6 (Diagonal principal)
        {2, 4, 6}  // Linha 7 (Diagonal secund�ria)
    };

    private void OnEnable()
    {
        var root = GetComponent<UIDocument>().rootVisualElement;
        labelTurno = root.Q<Label>("label-turno");
        labelPlacarJogador = root.Q<Label>("placar-jogador");
        labelPlacarEmpate = root.Q<Label>("placar-empate");
        labelPlacarPC = root.Q<Label>("placar-pc");

        //tabuleiro
        var botoesEncontrados = root.Query<Button>(className: "casa-tabuleiro").ToList();

        for (int i = 0; i < botoesEncontrados.Count; i++)
        {
            casas.Add(botoesEncontrados[i]);
            int indice = i; // Cache do �ndice para a express�o lambda

            // Vincula o clique de cada casa passando o seu n�mero (0 a 8)
            botoesEncontrados[i].clicked += () => JogadaDoJogador(indice);
        }

        botaoReiniciar = root.Q<Button>("botao-reiniciar");
        botaoReiniciar.clicked += ResetarTabuleiro;
        //evento clicked do bot�o reiniciar?
        AtualizarTextoPlacar();
        ResetarTabuleiro();
    }

    void JogadaDoJogador(int indice)
    {
        //testar se a jogada esta correta
        if (!jogoAtivo || !vezDoJogador || tabuleiroLogico[indice] != "")
        {
            return; // Jogada inv�lida
        }

        //jogar
        MarcarCasa(indice, "X");

        //verificar a vit�ria do jogador
        if (VerificarFimDeJogo("X")) return;

        //falar para o pc jogar
        vezDoJogador = false;
        labelTurno.text = "Vez do PC! (O)";
        //funcao jogada do pc
        StartCoroutine(TurnoDoComputador());
    }

    IEnumerator TurnoDoComputador()
    {
        yield return new WaitForSeconds(0.5f); // Espera 0.5 segundos antes de jogar
        if (!jogoAtivo) yield break; // Se o jogo n�o estiver ativo, sai da coroutine

        //super IA.
        List<int> casasLives = new List<int>();
        for (int i = 0; i < tabuleiroLogico.Length; i++)
        {
            if (tabuleiroLogico[i] == "")
            {
                casasLives.Add(i);
            }
        }

        if (casasLives.Count > 0)
        {
            //Aqui esta a IA
            //Poderia ter escolhido a primeira casa vazia,
            //mas para deixar o jogo mais interessante, escolhi uma casa aleat�ria

            int indiceSorteado = casasLives[Random.Range(0, casasLives.Count)];
            MarcarCasa(indiceSorteado, "O");

            //verificar a vit�ria do pc
            if (VerificarFimDeJogo("O")) yield break;
        }

        vezDoJogador = true;
        labelTurno.text = "Sua Vez! (X)";
    }

    bool VerificarFimDeJogo(string simbolo)
    {
        // Verifica as 8 combina��es de vit�ria
        for (int i = 0; i < combinacoesVitoria.GetLength(0); i++)
        {
            if (tabuleiroLogico[combinacoesVitoria[i, 0]] == simbolo &&
                tabuleiroLogico[combinacoesVitoria[i, 1]] == simbolo &&
                tabuleiroLogico[combinacoesVitoria[i, 2]] == simbolo)
            {
                if (simbolo == "X")
                {
                    vitoriasJogador++;
                    labelTurno.text = "Voc� Ganhou! ";
                }
                else
                {
                    vitoriasPC++;
                    labelTurno.text = "O PC Ganhou! ";
                }

                FinalizarRodada();
                return true;
            }
        }

        // Verifica Empate (Velha)
        if (!System.Array.Exists(tabuleiroLogico, elemento => elemento == ""))
        {
            empates++;
            labelTurno.text = "Deu Velha!";
            FinalizarRodada();
            return true;
        }

        return false;
    }


    void FinalizarRodada()
    {
        jogoAtivo = false;
        AtualizarTextoPlacar();
    }
    void MarcarCasa(int indice, string simbolo)
    {
        casas[indice].text = simbolo;
        casas[indice].SetEnabled(false);
        tabuleiroLogico[indice] = simbolo;
    }

    void AtualizarTextoPlacar()
    {
        //if (labelPlacarJogador!= null) labelPlacarJogador.text = $"Jogador: {vitoriasJogador}";
        //if (labelPlacarEmpate != null) labelPlacarEmpate.text = $"Empates: {empates}";
        //if (labelPlacarPC != null) labelPlacarPC.text = $"PC: {vitoriasPC}";

        if (labelPlacarJogador != null) labelPlacarJogador.text = $"{vitoriasJogador}";
        if (labelPlacarEmpate != null) labelPlacarEmpate.text = $"{empates}";
        if (labelPlacarPC != null) labelPlacarPC.text = $"{vitoriasPC}";
    }

    void ResetarTabuleiro()
    {
        vezDoJogador = true;
        jogoAtivo = true;
        labelTurno.text = "Sua Vez! (X)";

        for (int i = 0; i < casas.Count; i++)
        {
            casas[i].text = "";
            casas[i].SetEnabled(true);
            tabuleiroLogico[i] = "";
        }
    }

}
